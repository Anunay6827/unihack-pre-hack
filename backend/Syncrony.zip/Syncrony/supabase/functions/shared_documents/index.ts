import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.3";

const SUP_URL = Deno.env.get("_SUPABASE_URL")!;
const SUP_KEY = Deno.env.get("_SUPABASE_KEY")!;
const supabase = createClient(SUP_URL, SUP_KEY);

Deno.serve(async (req) => {
  try {
    const { id, fileContent, language } = await req.json();

    if (!id || !fileContent) {
      return new Response(
        JSON.stringify({ message: "Document ID and fileContent are required" }),
        { status: 400, headers: { "Content-Type": "application/json" } }
      );
    }

    // Step 1: Get file name from DB (content column)
    const { data: docData, error: fetchErr } = await supabase
      .from("shared_documents")
      .select("content")
      .eq("id", id)
      .single();

    if (fetchErr || !docData?.content) {
      return new Response(
        JSON.stringify({ message: "Document not found", error: fetchErr?.message }),
        { status: 404, headers: { "Content-Type": "application/json" } }
      );
    }

    const fileName = docData.content.trim(); // e.g., "code.txt"

    // Step 2: Overwrite file in "documents" bucket
    const fileBlob = new Blob([fileContent], { type: "text/plain" });

    const { error: uploadError } = await supabase.storage
      .from("documents")
      .upload(fileName, fileBlob, {
        upsert: true, // ensures overwrite
      });

    if (uploadError) {
      return new Response(
        JSON.stringify({ message: "Failed to upload file", error: uploadError.message }),
        { status: 500, headers: { "Content-Type": "application/json" } }
      );
    }

    // Step 3: Update DB metadata (language and timestamp)
    const { error: updateError } = await supabase
      .from("shared_documents")
      .update({
        language: language || "plaintext",
        last_updated: new Date().toISOString(),
      })
      .eq("id", id);

    if (updateError) {
      return new Response(
        JSON.stringify({ message: "Updated file, but failed to update metadata", error: updateError.message }),
        { status: 500, headers: { "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({
        message: "Document updated successfully",
        file: fileName,
      }),
      { status: 200, headers: { "Content-Type": "application/json" } }
    );

  } catch (err: unknown) {
    const errorMessage = err instanceof Error ? err.message : "Unknown error";

    return new Response(
      JSON.stringify({
        message: "Internal Server Error",
        error: errorMessage,
      }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    );
  }
});